-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `price` float(6,2) DEFAULT NULL,
  `year_published` int DEFAULT NULL,
  `page_count` int DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `cover_type` varchar(15) DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'Harry Potter i Kamień Filozoficzny',80.00,1997,326,'fantasy','twarda','https://ecsmedia.pl/c/harry-potter-i-kamien-filozoficzny-tom-1-b-iext43794838.jpg'),(2,'Harry Potter i Komnata Tajemnic',82.00,1998,359,'fantasy','twarda','https://ecsmedia.pl/c/harry-potter-i-komnata-tajemnic-tom-2-b-iext43244666.jpg'),(3,'Harry Potter i więźień Azkabanu',79.00,1999,464,'fantasy','twarda','https://image.ceneostatic.pl/data/products/45863470/i-harry-potter-i-wiezien-azkabanu.jpg'),(4,'Harry Potter i Czara Ognia',90.00,2000,765,'fantasy','twarda','https://image.ceneostatic.pl/data/products/46228651/i-harry-potter-i-czara-ognia.jpg'),(5,'Harry Potter i Zakon Feniksa',95.00,2003,955,'fantasy','twarda','https://ecsmedia.pl/c/harry-potter-i-zakon-feniksa-tom-5-b-iext43290406.jpg'),(6,'Harry Potter i Książę Półkrwi',90.00,2005,704,'fantasy','twarda','https://ecsmedia.pl/c/harry-potter-i-ksiaze-polkrwi-tom-6-b-iext43798777.jpg'),(7,'Harry Potter i Insygnia Śmierci',88.00,2007,784,'fantasy','twarda','https://ecsmedia.pl/c/harry-potter-i-insygnia-smierci-tom-7-w-iext43290390.jpg'),(8,'Dobry gliniarz',45.00,2019,528,'thriller','miękka','https://image.ceneostatic.pl/data/products/74683176/i-dobry-gliniarz-charles-campisi-gordon-dillow-ksiazka.jpg'),(9,'Normalni ludzie',60.00,2018,304,'literatura piękna','twarda','https://s.lubimyczytac.pl/upload/books/4911000/4911105/794775-352x500.jpg'),(10,'Wierzyliśmy jak nikt',76.00,2018,624,'literatura piękna','twarda','https://s.lubimyczytac.pl/upload/books/4918000/4918931/797569-352x500.jpg'),(11,'Dziewczyna z pociągu',40.00,2015,328,'thriller','miękka','https://www.swiatksiazki.pl/media/catalog/product/cache/a946e6dbdb55333e1c3d566a3e38b923/9/9/99906329123.jpg'),(12,'Pachnidło. Historia pewnego mordercy',50.00,2015,254,'thriller','miękka','https://s.lubimyczytac.pl/upload/books/4850000/4850006/665281-352x500.jpg'),(13,'To',100.00,2019,1104,'horror','twarda','https://s.lubimyczytac.pl/upload/books/4892000/4892189/744634-352x500.jpg'),(14,'Dracula',65.00,2018,428,'horror','miękka','https://s.lubimyczytac.pl/upload/books/4819000/4819768/657964-352x500.jpg'),(15,'Bezsenność',40.00,2016,656,'horror','miękka','https://stephenking.pl/wp-content/uploads/2016/02/Bezsenno%C5%9B%C4%87.jpg'),(16,'Gwiazd naszych wina',35.00,2014,320,'literatura młodzieżowa','miękka','https://s.lubimyczytac.pl/upload/books/225000/225665/289291-352x500.jpg'),(17,'Dziesięć płytkich oddechów',45.00,2014,421,'literatura młodzieżowa','miękka','https://s.lubimyczytac.pl/upload/books/222000/222807/278462-352x500.jpg'),(18,'Dziewczyny z Powstania',63.00,2014,320,'literatura faktu','twarda','https://s.lubimyczytac.pl/upload/books/218000/218407/263658-352x500.jpg'),(19,'Dzisiaj narysujemy śmierć',52.00,2018,208,'literatura faktu','miękka','https://s.lubimyczytac.pl/upload/books/4848000/4848978/663412-352x500.jpg'),(20,'Złączeni nienawiścią',67.00,2020,320,'romans','twarda','https://s.lubimyczytac.pl/upload/books/4911000/4911231/782240-352x500.jpg'),(21,'Zmierzch',55.00,2007,416,'romans','miękka','https://s.lubimyczytac.pl/upload/books/51000/51794/352x500.jpg'),(22,'Pięćdziesiąt twarzy Greya',76.00,2015,608,'romans','twarda','https://s.lubimyczytac.pl/upload/books/242000/242780/367354-352x500.jpg'),(23,'Księżyc w nowiu',55.00,2009,488,'romans','twarda','https://s.lubimyczytac.pl/upload/books/21000/21525/352x500.jpg'),(24,'Zdążyć przed Panem Bogiem',42.00,2018,125,'literatura faktu','miękka','https://s.lubimyczytac.pl/upload/books/4859000/4859145/682943-352x500.jpg'),(25,'Inferno',48.00,2016,688,'thriller','twarda','https://s.lubimyczytac.pl/upload/books/3670000/3670880/507959-352x500.jpg'),(26,'Doktor Sen',70.00,2019,656,'horror','twarda','https://s.lubimyczytac.pl/upload/books/4903000/4903160/765657-352x500.jpg'),(27,'Cesarz',50.00,2016,172,'literatura faktu','miękka','https://s.lubimyczytac.pl/upload/books/4224000/4224793/542975-352x500.jpg'),(28,'Miłość w czasach zarazy',45.00,2017,496,'literatura piękna','miękka','https://s.lubimyczytac.pl/upload/books/4807000/4807144/597965-352x500.jpg'),(29,'Małe życie',56.00,2018,817,'literatura piękna','miękka','https://s.lubimyczytac.pl/upload/books/4862000/4862789/703690-352x500.jpg'),(30,'Papierowe miasta',45.00,2015,400,'literatura młodzieżowa','miękka','https://s.lubimyczytac.pl/upload/books/259000/259625/395693-352x500.jpg'),(31,'Czerwień rubinu',80.00,2017,344,'literatura młodzieżowa','miękka','https://s.lubimyczytac.pl/upload/books/4399000/4399069/563776-352x500.jpg');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-30 13:38:59
